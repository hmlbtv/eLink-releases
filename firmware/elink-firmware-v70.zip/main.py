"""Stable launcher (never replaced by OTA). Runs app.py and undoes a bad update if it crashes.
If the dashboard asked for a firmware update (ota_mode.json), it runs updater.py instead: a tiny program with almost all of the RAM free."""
import sys

try:
    import os
    os.stat("ota_mode.json")
    update_mode = True
except OSError:
    update_mode = False

if update_mode:
    try:
        import updater
        updater.run()
    except Exception as exc:
        sys.print_exception(exc)
        try: updater.clear_flag()
        except Exception: pass
    for _name in ("updater", "ota", "wifi_store", "apctl"):     # hand the memory back before the normal program starts
        sys.modules.pop(_name, None)
    import gc
    gc.collect()

try:
    import app
    app.run()
except Exception as exc:
    sys.print_exception(exc)
    try:
        import ota
        if ota.rollback_now():
            print("Crashed on an unconfirmed update; restored the previous firmware")
            import machine
            machine.reset()
    except Exception as inner:
        print("rollback failed:", inner)
    raise
finally:
    try:
        import uasyncio
        uasyncio.new_event_loop()
    except Exception:
        pass
