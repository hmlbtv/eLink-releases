# replaced at build time
PUBKEY = ""
