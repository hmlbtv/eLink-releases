"""Firmware version. Bump on every release; OTA only moves devices to a HIGHER number."""
FW_VERSION = 70
