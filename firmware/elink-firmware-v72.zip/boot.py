"""Runs before main.py. NEVER replaced by OTA (deploy over USB). Guards against bad updates.

A pending update (ota_state.json) is rolled back if it was not fully applied, if a module
fails to import, or if the node rebooted more than 3 times without confirming it.
"""
import os
import ujson


def _exists(path):
    try:
        os.stat(path)
        return True
    except OSError:
        return False


def _drop_old_stage():
    """Before FW44 the upload folder was called "ota". A folder with a module's name wins over ota.mpy at import
    (the module then has no contents), so remove it."""
    try:
        if os.stat("ota")[0] & 0x4000:
            for entry in os.listdir("ota"):
                os.remove("ota/" + entry)
            os.rmdir("ota")
            print("removed old ota folder")
    except OSError as exc:
        print("old ota folder:", exc)


def _rollback(state):
    for name in state.get("files", []):
        try:
            if name in state.get("added", []):
                if _exists(name): os.remove(name)
            elif _exists(name + ".bak"):
                if _exists(name): os.remove(name)
                os.rename(name + ".bak", name)
        except OSError as exc:
            print("rollback", name, exc)
    with open("ota_rollback.json", "w") as handle:
        ujson.dump({"ver": state.get("ver")}, handle)
    try: os.remove("ota_state.json")
    except OSError: pass
    print("OTA update", state.get("ver"), "rolled back")


def _check():
    try:
        with open("ota_state.json") as handle:
            state = ujson.load(handle)
    except (OSError, ValueError):
        return
    if "files" not in state:
        return
    state["boots"] = state.get("boots", 0) + 1
    with open("ota_state.json", "w") as handle:
        ujson.dump(state, handle)
    bad = (not state.get("applied")) or state["boots"] > 3
    if not bad:
        try:
            for name in state["files"]:
                if name.endswith(".py"):
                    __import__(name[:-3])
                elif name.endswith(".mpy"):
                    __import__(name[:-4])
        except BaseException as exc:
            print("OTA import check failed:", exc)
            bad = True
    if bad:
        _rollback(state)
        import machine
        machine.reset()


_drop_old_stage()
_check()
